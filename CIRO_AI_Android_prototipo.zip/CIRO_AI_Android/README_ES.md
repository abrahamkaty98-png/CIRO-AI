# CIRO AI — prototipo Android

Este paquete contiene el **prototipo visual inicial** de CIRO AI, pensado para una Samsung Galaxy Tab Active3 con Android 11.

## Qué incluye
- Interfaz negro y dorado adaptable.
- Esfera dorada animada.
- Tarjetas de acceso a conversación, estudio de tatuajes, generación de imágenes y galería.
- Botón visual para activar/desactivar el modo de voz (todavía no conectado al micrófono).

## Qué NO incluye todavía
Este prototipo **no es aún una aplicación terminada ni un APK instalable**. No tiene conectado un modelo de IA, generación real de imágenes, reconocimiento de voz, voz hablada, memoria en la nube ni autenticación. Esas funciones requieren integración y pruebas posteriores.

## Cómo compilar
1. Abre el proyecto en Android Studio o en un entorno Android compatible.
2. Deja que Gradle sincronice las dependencias.
3. Compila con `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. Instala el APK de depuración en la tablet para probar la interfaz.

Configuración: `minSdk 23`, `targetSdk 35`, `compileSdk 35`. Android 11 (API 30) está dentro del rango compatible, sujeto a las pruebas en el dispositivo.

## Próxima etapa
Conectar un backend seguro para chat e imágenes, Speech-to-Text y Text-to-Speech. Las claves de API deben guardarse en el servidor, nunca dentro del APK.
