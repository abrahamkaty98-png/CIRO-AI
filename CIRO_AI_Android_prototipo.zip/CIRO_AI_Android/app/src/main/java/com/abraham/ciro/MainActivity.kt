package com.abraham.ciro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Black = Color(0xFF090909)
private val Gold = Color(0xFFD6AD55)
private val PaleGold = Color(0xFFFFE6A3)
private val Muted = Color(0xFFB8A77F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CiroHome() }
    }
}

@Composable
fun CiroHome() {
    var listening by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf("Inicio") }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = Black) {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("CIRO", color = PaleGold, fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp)
                        Text("TU ASISTENTE INTELIGENTE", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    Text("● PRIVADO", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }

                Spacer(Modifier.height(22.dp))
                Text("Hola. Soy CIRO.", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Medium)
                Text("¿Qué vamos a crear hoy?", color = Muted, fontSize = 15.sp)

                Spacer(Modifier.height(10.dp))
                GoldenOrb(Modifier.size(230.dp))
                Text(
                    if (listening) "MODO DE VOZ ACTIVADO" else "PULSA PARA CONVERSAR",
                    color = if (listening) PaleGold else Muted,
                    fontSize = 11.sp,
                    letterSpacing = 2.sp
                )
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { listening = !listening },
                    colors = ButtonDefaults.buttonColors(containerColor = if (listening) Color(0xFF6F2424) else Gold),
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.fillMaxWidth(0.78f).height(52.dp)
                ) {
                    Text(if (listening) "Desactivar micrófono" else "Activar conversación", color = if (listening) Color.White else Black, fontWeight = FontWeight.Bold)
                }
                Text(
                    "Prototipo visual: el botón todavía no activa el micrófono.",
                    color = Color(0xFF80796B), fontSize = 10.sp
                )

                Spacer(Modifier.height(24.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FeatureCard("✦", "Conversar", "Asistente personal", Modifier.weight(1f))
                    FeatureCard("✧", "Crear tatuaje", "Diseños con IA", Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FeatureCard("▧", "Generar imagen", "Arte desde texto", Modifier.weight(1f))
                    FeatureCard("⌑", "Mis diseños", "Galería privada", Modifier.weight(1f))
                }
                Spacer(Modifier.weight(1f))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    listOf("Inicio", "Chat", "Estudio", "Ajustes").forEach { item ->
                        TextButton(onClick = { selected = item }) {
                            Text(item, color = if (selected == item) PaleGold else Muted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GoldenOrb(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by transition.animateFloat(
        initialValue = 0.92f, targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(1900), RepeatMode.Reverse),
        label = "pulse"
    )
    val rotation by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(9000)),
        label = "rotation"
    )

    Canvas(modifier = modifier) {
        val c = Offset(size.width / 2f, size.height / 2f)
        val r = size.minDimension * 0.34f * pulse
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFFFF1C4), Color(0xFFD6AD55), Color(0xFF76501B), Color.Transparent),
                center = c, radius = r * 1.75f
            ),
            radius = r * 1.75f, center = c
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFFFF4D1), Color(0xFFE4B94F), Color(0xFF8A5A17), Color(0xFF2B1B08)),
                center = Offset(c.x - r * 0.28f, c.y - r * 0.35f), radius = r * 1.45f
            ),
            radius = r, center = c
        )
        drawCircle(color = PaleGold.copy(alpha = 0.8f), radius = r * 1.23f, center = c, style = Stroke(width = 2.2.dp.toPx()))
        val a = Math.toRadians(rotation.toDouble())
        val orbit = Offset(c.x + kotlin.math.cos(a).toFloat() * r * 1.22f, c.y + kotlin.math.sin(a).toFloat() * r * 0.48f)
        drawCircle(color = Color.White.copy(alpha = 0.9f), radius = 4.dp.toPx(), center = orbit)
        drawCircle(color = Gold.copy(alpha = 0.45f), radius = r * 1.48f, center = c, style = Stroke(width = 1.dp.toPx()))
    }
}

@Composable
fun FeatureCard(icon: String, title: String, subtitle: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(Color(0xFF17140F), RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Text(icon, color = PaleGold, fontSize = 22.sp)
        Spacer(Modifier.height(7.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Text(subtitle, color = Muted, fontSize = 11.sp)
    }
}
